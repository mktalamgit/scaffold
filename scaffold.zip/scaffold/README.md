# Scaffold: Fastify + React/Vite + Postgres + Python (uv)

```
apps/api    Fastify REST API (CRUD on /api/tasks)
apps/web    React + Vite UI (proxies /api -> :3001)
python/     uv project: seed + report scripts
db/init.sql Schema (auto-applied by docker compose)
```

## Prerequisites
Node 20.6+, pnpm 9+, Docker, [uv](https://docs.astral.sh/uv/)

## Run
```bash
pnpm install
pnpm db:up          # Postgres on :5432
pnpm dev            # API :3001 + web :5173
pnpm seed           # optional sample data (Python/uv)
pnpm report         # task stats (Python/uv)
```

## API
| Method | Path            | Purpose        |
|--------|-----------------|----------------|
| GET    | /api/tasks      | List           |
| GET    | /api/tasks/:id  | Get one        |
| POST   | /api/tasks      | Create         |
| PATCH  | /api/tasks/:id  | Update partial |
| DELETE | /api/tasks/:id  | Delete         |
