"""Print task stats. Run: pnpm report"""
import os
import psycopg

with psycopg.connect(os.environ["DATABASE_URL"]) as conn:
    total, done = conn.execute(
        "SELECT count(*), count(*) FILTER (WHERE done) FROM tasks"
    ).fetchone()

pct = (done / total * 100) if total else 0
print(f"Total: {total} | Done: {done} ({pct:.0f}%)")
