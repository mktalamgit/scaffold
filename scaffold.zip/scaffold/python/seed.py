"""Insert sample tasks. Run: pnpm seed  (or: uv run --env-file ../.env seed.py)"""
import os
import psycopg

SAMPLES = [
    ("Set up project", "Scaffold generated", True),
    ("Build first feature", "Add a new route + UI", False),
    ("Write tests", "", False),
]

with psycopg.connect(os.environ["DATABASE_URL"]) as conn:
    with conn.cursor() as cur:
        cur.executemany(
            "INSERT INTO tasks (title, description, done) VALUES (%s, %s, %s)", SAMPLES
        )
    conn.commit()
print(f"Inserted {len(SAMPLES)} tasks")
