import { useEffect, useState } from "react";
import { tasksApi } from "./api.js";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [editing, setEditing] = useState(null); // { id, title }
  const [error, setError] = useState(null);

  const load = () => tasksApi.list().then(setTasks).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const run = async (fn) => {
    try { setError(null); await fn(); await load(); } catch (e) { setError(e.message); }
  };

  const add = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    run(async () => { await tasksApi.create({ title }); setTitle(""); });
  };

  const saveEdit = () =>
    run(async () => { await tasksApi.update(editing.id, { title: editing.title }); setEditing(null); });

  return (
    <main>
      <h1>Tasks</h1>
      {error && <p className="error">{error}</p>}

      <form onSubmit={add}>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="New task…" />
        <button>Add</button>
      </form>

      <ul>
        {tasks.map((t) => (
          <li key={t.id} className={t.done ? "done" : ""}>
            <input
              type="checkbox"
              checked={t.done}
              onChange={() => run(() => tasksApi.update(t.id, { done: !t.done }))}
            />
            {editing?.id === t.id ? (
              <>
                <input
                  value={editing.title}
                  onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                />
                <button onClick={saveEdit}>Save</button>
                <button onClick={() => setEditing(null)}>Cancel</button>
              </>
            ) : (
              <>
                <span>{t.title}</span>
                <button onClick={() => setEditing({ id: t.id, title: t.title })}>Edit</button>
                <button onClick={() => run(() => tasksApi.remove(t.id))}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </main>
  );
}
