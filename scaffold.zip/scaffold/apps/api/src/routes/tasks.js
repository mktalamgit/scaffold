import { pool } from "../db.js";

const idParams = {
  type: "object",
  properties: { id: { type: "integer" } },
  required: ["id"],
};

export default async function taskRoutes(app) {
  // READ (list)
  app.get("/tasks", async () => {
    const { rows } = await pool.query("SELECT * FROM tasks ORDER BY id DESC");
    return rows;
  });

  // READ (one)
  app.get("/tasks/:id", { schema: { params: idParams } }, async (req, reply) => {
    const { rows } = await pool.query("SELECT * FROM tasks WHERE id = $1", [req.params.id]);
    if (!rows[0]) return reply.notFound();
    return rows[0];
  });

  // CREATE
  app.post(
    "/tasks",
    {
      schema: {
        body: {
          type: "object",
          required: ["title"],
          properties: {
            title: { type: "string", minLength: 1 },
            description: { type: "string" },
          },
        },
      },
    },
    async (req, reply) => {
      const { title, description = "" } = req.body;
      const { rows } = await pool.query(
        "INSERT INTO tasks (title, description) VALUES ($1, $2) RETURNING *",
        [title, description]
      );
      return reply.code(201).send(rows[0]);
    }
  );

  // UPDATE (partial)
  app.patch(
    "/tasks/:id",
    {
      schema: {
        params: idParams,
        body: {
          type: "object",
          properties: {
            title: { type: "string", minLength: 1 },
            description: { type: "string" },
            done: { type: "boolean" },
          },
        },
      },
    },
    async (req, reply) => {
      const { title, description, done } = req.body;
      const { rows } = await pool.query(
        `UPDATE tasks SET
           title = COALESCE($2, title),
           description = COALESCE($3, description),
           done = COALESCE($4, done),
           updated_at = now()
         WHERE id = $1 RETURNING *`,
        [req.params.id, title ?? null, description ?? null, done ?? null]
      );
      if (!rows[0]) return reply.notFound();
      return rows[0];
    }
  );

  // DELETE
  app.delete("/tasks/:id", { schema: { params: idParams } }, async (req, reply) => {
    const { rowCount } = await pool.query("DELETE FROM tasks WHERE id = $1", [req.params.id]);
    if (!rowCount) return reply.notFound();
    return reply.code(204).send();
  });
}
