import Fastify from "fastify";
import taskRoutes from "./routes/tasks.js";
import { pool } from "./db.js";

const app = Fastify({ logger: true });

app.decorateReply("notFound", function () {
  return this.code(404).send({ error: "Not found" });
});

app.get("/health", async () => {
  await pool.query("SELECT 1");
  return { status: "ok" };
});

app.register(taskRoutes, { prefix: "/api" });

const port = Number(process.env.API_PORT ?? 3001);
app.listen({ port, host: "0.0.0.0" }).catch((err) => {
  app.log.error(err);
  process.exit(1);
});
